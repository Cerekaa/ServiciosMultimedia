namespace Fusion.Addons.KCC
{
	using UnityEngine;

	public sealed class DisabledInPlayModeAttribute : PropertyAttribute
	{
	}
}
