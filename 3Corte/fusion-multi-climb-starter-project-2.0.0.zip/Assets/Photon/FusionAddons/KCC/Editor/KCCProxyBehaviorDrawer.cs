// This class has been removed.
