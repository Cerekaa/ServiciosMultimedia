using Fusion.Menu;

namespace MultiClimb.Menu
{
    public class MenuUIController : FusionMenuUIController<FusionMenuConnectArgs> { }
}
